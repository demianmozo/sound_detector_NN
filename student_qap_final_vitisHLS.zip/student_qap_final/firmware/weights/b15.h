//Numpy array shape [4]
//Min -0.625000000000
//Max 0.375000000000
//Number of zeros 0

#ifndef B15_H_
#define B15_H_

#ifndef __SYNTHESIS__
bias15_t b15[4];
#else
bias15_t b15[4] = {-0.625, 0.375, -0.500, 0.125};
#endif

#endif
